# Flutter Android CI image

Imagen Linux para los jobs Android de GitLab CI/CD del proyecto.

Incluye:

- Flutter `3.41.7`, alineado con `.fvmrc`.
- Dart incluido en ese SDK de Flutter.
- OpenJDK 17.
- Android SDK command-line tools `14742923`.
- Android platform `android-36`.
- Android build-tools `36.0.0`.
- Android platforms `34` y `35`, build-tools `35.0.0`, NDK `28.2.13676358`
  y CMake `3.22.1`, necesarios por dependencias Android del proyecto.
- Android emulator package.
- Ruby, Bundler y Fastlane `2.234.x`.
- Jenkins LTS con un job inicial `flutter-repo-job`.

No cubre iOS: la compilacion iOS debe ejecutarse en un runner macOS con Xcode.

La imagen se construye como `linux/amd64` por defecto, tambien en maquinas
Apple Silicon. El paquete `emulator` del Android SDK no esta disponible para
Linux `arm64`.

## Build local

Desde la raiz del repositorio:

```sh
docker build \
  -t jccm-espacio-ciudadano/flutter-android-ci:3.41.7 \
  gitlab-ci/docker/flutter-android
```

Si ya estas dentro de `gitlab-ci/docker/flutter-android`:

```sh
docker build \
  -t jccm-espacio-ciudadano/flutter-android-ci:3.41.7 \
  .
```

La imagen deja preconfigurado como repo por defecto el remoto SSH del proyecto:

```txt
git@github.com:gtoldos-hiberuscom/mobile-flutter-jccm-espacio-ciudadano.git
```

Si quieres fijar otro repositorio o rama en la imagen:

```sh
docker build \
  --build-arg JENKINS_DEFAULT_REPO_URL=git@github.com:org/repo.git \
  --build-arg JENKINS_DEFAULT_REPO_BRANCH=feature/cicd \
  -t jccm-espacio-ciudadano/flutter-android-ci:3.41.7 \
  gitlab-ci/docker/flutter-android
```

Para una imagen preparada tambien para crear un AVD dentro del contenedor:

```sh
docker build \
  --build-arg INSTALL_ANDROID_SYSTEM_IMAGE=true \
  -t jccm-espacio-ciudadano/flutter-android-ci:3.41.7-emulator \
  gitlab-ci/docker/flutter-android
```

Esa variante es bastante mas grande; usala solo si el runner ejecutara
`flutter test integration_test` contra emulador Android dentro del contenedor.

## Smoke test local

```sh
docker run --rm \
  -v "$PWD:/workspace" \
  -w /workspace \
  jccm-espacio-ciudadano/flutter-android-ci:3.41.7 \
  ci-image-doctor
```

## Jenkins local

Arrancar Jenkins:

```sh
docker run --rm \
  -p 8080:8080 \
  -v jccm-jenkins-home:/var/lib/jenkins \
  -e JENKINS_ADMIN_USER=admin \
  -e JENKINS_ADMIN_PASSWORD=admin \
  jccm-espacio-ciudadano/flutter-android-ci:3.41.7
```

Abre `http://localhost:8080` y entra con el usuario configurado. El job
`flutter-repo-job` ya esta creado y acepta estos parametros:

- `REPO_URL`: URL git del repositorio; si queda vacio usa `JENKINS_JOB_REPO_URL`.
- `GIT_BRANCH`: rama a clonar; si queda vacio usa `JENKINS_JOB_BRANCH`.
- `GIT_DEPTH`: profundidad del clone; usa `0` para clone completo.
- `BUILD_TARGET`: `appbundle`, `apk` o `custom`.
- `DART_DEFINE_FILE`: JSON de `--dart-define-from-file`; si queda vacio no se pasa.
- `EXTRA_BUILD_ARGS`: argumentos extra para `flutter build`.
- `RUN_TESTS`: ejecuta `flutter test` antes del build.
- `CLEAN_BEFORE_BUILD`: ejecuta `flutter clean` antes de `pub get`.
- `JOB_COMMAND`: comando custom; si se rellena, tiene prioridad sobre el resto.

Antes de ejecutar `JOB_COMMAND`, el job ajusta `android/gradle.properties` en el
clone para CI: baja el heap de Gradle, desactiva el daemon, desactiva el file
watcher nativo y limita workers. Esto evita caidas habituales en Docker Desktop
como `Gradle build daemon disappeared unexpectedly` o `Couldn't poll for events`.

Uso recomendado del freestyle job:

- abre `flutter-repo-job`;
- pulsa `Build with Parameters`;
- rellena `REPO_URL` y `GIT_BRANCH` si no quieres depender de defaults del contenedor;
- deja `JOB_COMMAND` vacio para que Jenkins componga un build Android normal;
- usa `JOB_COMMAND` solo para ejecuciones avanzadas o ad hoc.

Si `JOB_COMMAND` queda vacio, el job genera automaticamente un flujo de este
tipo:

- `flutter clean` si `CLEAN_BEFORE_BUILD=true`;
- `flutter pub get`;
- `flutter test` si `RUN_TESTS=true`;
- `flutter build appbundle` o `flutter build apk`.

Al terminar, Jenkins archiva automaticamente los `.aab` y `.apk` generados en
`repo/build/app/outputs/...`.

Para un repo privado por SSH, la forma mas directa es pasar una clave por
variable:

```sh
docker run --rm \
  -p 8080:8080 \
  -v jccm-jenkins-home:/var/lib/jenkins \
  -e JENKINS_GIT_SSH_PRIVATE_KEY="$(cat ~/.ssh/id_ed25519)" \
  -e JENKINS_ADMIN_PASSWORD=admin \
  jccm-espacio-ciudadano/flutter-android-ci:3.41.7
```

Tambien puedes montar una carpeta `.ssh` ya preparada dentro del home de
Jenkins, siempre que sus permisos permitan lectura al usuario `jenkins` del
contenedor:

```sh
docker run --rm \
  -p 8080:8080 \
  -v jccm-jenkins-home:/var/lib/jenkins \
  -v "$HOME/.ssh:/var/lib/jenkins/.ssh:ro" \
  -e JENKINS_ADMIN_PASSWORD=admin \
  jccm-espacio-ciudadano/flutter-android-ci:3.41.7
```

La opcion mas robusta para Docker Desktop es montar una clave privada como
fichero y pasar su ruta:

```sh
docker run --rm \
  -p 8080:8080 \
  -v jccm-jenkins-home:/var/lib/jenkins \
  -v "$HOME/.ssh/jenkins_bitbucket_ed25519:/run/secrets/bitbucket_ssh_key:ro" \
  -e JENKINS_GIT_SSH_PRIVATE_KEY_FILE=/run/secrets/bitbucket_ssh_key \
  -e JENKINS_GIT_KNOWN_HOSTS="$(ssh-keyscan bitbucket.org 2>/dev/null)" \
  -e JENKINS_ADMIN_PASSWORD=admin \
  jccm-espacio-ciudadano/flutter-android-ci:3.41.7
```

Si la clave privada tiene passphrase, añade tambien:

```sh
-e JENKINS_GIT_SSH_PASSPHRASE='tu-passphrase'
```

Para CI suele ser mas simple usar una deploy key dedicada sin passphrase y con
permiso de solo lectura sobre el repositorio.

Importante: el bootstrap resincroniza en cada arranque:

- `init.groovy.d/*`
- `jobs/flutter-repo-job/config.xml`

Eso permite actualizar el job freestyle sembrado y los scripts de arranque sin
tener que borrar el volumen local de Jenkins en cada cambio.

Para comprobar que la clave montada es exactamente la misma que has subido a
Bitbucket, compara su fingerprint:

```sh
ssh-keygen -y -P 'tu-passphrase' -f ~/.ssh/jenkins_bitbucket_ci_ed25519 | ssh-keygen -lf -
```

El fingerprint debe coincidir con la clave publica registrada en `Repository
settings -> Access keys` del repositorio correcto.

## Pipeline desde el repo

El repositorio incluye un [Jenkinsfile](/Users/gtoldos/Projecs/mobile-flutter-jccm-espacio-ciudadano/jccm_espacio_ciudadano/Jenkinsfile:1)
para usar un Pipeline job o `Pipeline script from SCM` en lugar del job
freestyle sembrado en Jenkins.

Ese pipeline:

- clona el repo desde SCM;
- ajusta `android/gradle.properties` para CI dentro del workspace;
- ejecuta `flutter pub get`;
- opcionalmente ejecuta `flutter test`;
- construye `appbundle` o `apk`;
- publica `.aab` y `.apk` como artifacts de Jenkins.

Es la opcion recomendada si vas a iterar a menudo sobre el proceso de build,
porque la logica deja de vivir en `JENKINS_HOME` y pasa a estar versionada en
el propio repositorio.

La imagen instala tambien los plugins minimos para `Pipeline + Git` y, al
arrancar Jenkins, crea o actualiza un job `flutter-repo-pipeline` y una
credencial SSH global si encuentra estas variables:

- `JENKINS_JOB_REPO_URL` o `JENKINS_PIPELINE_REPO_URL`
- `JENKINS_JOB_BRANCH` o `JENKINS_PIPELINE_BRANCH`
- `JENKINS_GIT_SSH_PRIVATE_KEY_FILE` o `JENKINS_GIT_SSH_PRIVATE_KEY`
- `JENKINS_GIT_SSH_PASSPHRASE` si la clave esta cifrada

Con eso, el job pipeline queda preparado sin necesidad de configurar la SCM
credential a mano en la UI.

Arranque recomendado para usar directamente el `Jenkinsfile` del repo por SSH:

```sh
docker run --rm \
  -p 8080:8080 \
  -v jccm-jenkins-home:/var/lib/jenkins \
  -v "$HOME/.ssh/jenkins_bitbucket_ci_ed25519:/run/secrets/bitbucket_ssh_key:ro" \
  -e JENKINS_ADMIN_USER=admin \
  -e JENKINS_ADMIN_PASSWORD=admin \
  -e JENKINS_PIPELINE_REPO_URL=git@bitbucket.org:hiberus/mobile-flutter-jccm-espacio-ciudadano.git \
  -e JENKINS_PIPELINE_BRANCH=feature/STORY-54-LifeEvents \
  -e JENKINS_GIT_SSH_PRIVATE_KEY_FILE=/run/secrets/bitbucket_ssh_key \
  -e JENKINS_GIT_SSH_PASSPHRASE='tu-passphrase' \
  -e JENKINS_GIT_KNOWN_HOSTS="$(ssh-keyscan bitbucket.org 2>/dev/null)" \
  jccm-espacio-ciudadano/flutter-android-ci:3.41.7
```

Con ese arranque, Jenkins levanta ya con el job `flutter-repo-pipeline`
apuntando al `Jenkinsfile` de la rama indicada. Lo normal a partir de ahi es
usar `Build with Parameters` o `Build Now` sobre ese job, no el freestyle
`flutter-repo-job`.

Los scripts de `init.groovy.d` y el `config.xml` de `flutter-repo-job` se
sincronizan en cada arranque del contenedor, asi que los cambios de bootstrap,
de credenciales SCM y del job freestyle ya no dependen del primer seed del
volumen `jccm-jenkins-home`.

## Uso previsto en GitLab

```yaml
image: registry.gitlab.com/<grupo>/<proyecto>/flutter-android-ci:3.41.7
```

El pipeline debe usar el wrapper Gradle del repositorio (`android/gradlew`) y
las variables CI recomendadas en `Flutter_CI_CD.md`, por ejemplo
`APP_VERSION`, `BUILD_NUMBER`, `FLAVOR` y `ENV_NAME`.
